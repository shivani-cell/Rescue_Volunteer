package com.example.searchnearbyhospitals;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);
    }
    public  void browserl(View view){
        Intent browserIntent=new Intent (Intent.ACTION_VIEW, Uri.parse("https://www.google.com.kh/search?q=nearby+hospitals&sxsrf=ALeKk00JCrvBV0hKSWNgB_jri9nkYyE57g%3A1617989878085&source=hp&ei=9pBwYO-5AvbZz7sP4bO-cA&oq=nearby+hospitals&gs_lcp=ChFtb2JpbGUtZ3dzLXdpei1ocBADMgQIIxAnMgQIIxAnMgIIADIFCAAQyQM6CgguEOoCECcQkwI6BwgjEOoCECc6BQgAEJECOggIABCxAxDJAzoFCAAQsQNQoCdY5kRg5UZoAXAAeACAAbMCiAH9F5IBCDAuMTQuMS4xmAEAoAEBsAEP&sclient=mobile-gws-wiz-hp&dlnr=1&sei=AJFwYKPhFrjbz7sPyM-ziA4"));
        startActivity (browserIntent);
    }
}