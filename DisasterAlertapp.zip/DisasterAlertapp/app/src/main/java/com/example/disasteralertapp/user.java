package com.example.disasteralertapp;

public class user {
    public String fullname,email,username,address;

    public user(){

    }
    public user(String fullname,String email,String username,String address){
        this.fullname=fullname;
        this.email=email;
        this.username=username;
        this.address=address;
    }
}
