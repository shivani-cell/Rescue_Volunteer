package com.example.disasteralertapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Pattern;

public class reg extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth mAuth;

    Button _btnReg, _btnLogin;
    EditText _txtName, _txtAdd, _txtEmail, _txtUser, _txtPass;
//private TextView register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_reg);
  mAuth= FirebaseAuth.getInstance ();

        _btnLogin = findViewById (R.id.btnLogin);

        _btnReg = findViewById (R.id.btnReg);
        _btnReg.setOnClickListener (this);

        _txtName = findViewById (R.id.txtName);
        _txtAdd = findViewById (R.id.txtAdd);
        _txtEmail = findViewById (R.id.txtEmail);
        _txtUser = findViewById (R.id.txtUser);

        _txtPass = findViewById (R.id.txtPass);

    }

    @Override
    public void onClick(View v) {
switch (v.getId ()){
    case R.id.btnLogin :
        startActivity (new Intent (  this,loginActivity.class));
        break;
    case R.id.btnReg:
        registeruser();
        break;
}
    }

    private void registeruser() {

        String name = _txtName.getText ( ).toString ( ).trim ();
        String address = _txtAdd.getText ( ).toString ( ).trim ();
        String email = _txtEmail.getText ( ).toString ( ).trim ();
        String username = _txtUser.getText ( ).toString ( ).trim ();
        String password = _txtPass.getText ( ).toString ( ).trim ();


        if(name.isEmpty ()){
           _txtName.setError ("full name is required");
           _txtName.requestFocus ();
           return;
        }
        if(address.isEmpty ()){
            _txtAdd.setError ("full address is required");
            _txtAdd.requestFocus ();
            return;
        }
        if(email.isEmpty ()){
            _txtEmail.setError ("Email is required");
            _txtEmail.requestFocus ();
            return;
        }
        if(Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            _txtEmail.setError ("please provide valid mail");
            _txtEmail.requestFocus ();
            return;
        }
        if(password.isEmpty ()){
            _txtPass.setError ("password is required");
            _txtPass.requestFocus ();
            return;
        }

        if(password.length ()<6){
            _txtPass.setError ("min password length should be 6 characters");
            _txtPass.requestFocus ();
            return;
        }

mAuth.createUserWithEmailAndPassword (email,password).addOnCompleteListener (new OnCompleteListener<AuthResult> ( ) {
    @Override
    public void onComplete(@NonNull Task<AuthResult> task) {
        if(task.isSuccessful ()){
            user user1=new user(name,email,username,address);
            FirebaseDatabase.getInstance ().getReference ("Users").child (FirebaseAuth.getInstance ().getUid ()).setValue (user1).addOnCompleteListener (new OnCompleteListener<Void> ( ) {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful ()){
                        Intent intent=new Intent ( reg.this,MainActivity.class );
                       // Toast.makeText (reg.this,"user has been register successfully",Toast.LENGTH_LONG ).show();
                    }
                    else {
                            Toast.makeText (reg.this,"failed to register",Toast.LENGTH_LONG ).show();
                    }
                }
            });

        }
        else{
            Toast.makeText (reg.this,"failed to register",Toast.LENGTH_LONG ).show();
        }
    }
});



    }
}