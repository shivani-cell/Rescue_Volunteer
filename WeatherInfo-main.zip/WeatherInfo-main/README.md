# WeatherAppBasic
It is basically a app made by using android studio , xml for gui and java as prograamming language .This app tells us the temparature ,humidty of different country and states.In this i have used the api of openweathermap website.By using this we can get the weather information of any location.
